Usage: 
simple, make and run, inside makefile uncomment the line for each option, it works on all tests and works with FUSE.

Makefile is modified due to added code files, but usage is same as was provided.
The file created for sfs file system is named sample_disk_name.fs and is in the same directory where the program is runned.
Maximum possible file size is 268*1024 bytes, if bigger write is done rest is not writen to file.

Note: 
In the test files MAX_FNAME_LENGTH and MAXFILENAME was used for maximum file name, so I defined MAXFILENAME in sfs_api.h and set to 23.
I modified the line in test files that defines MAX_FNAME_LENGTH to be equal to MAXFILENAME which is 23 (line 17 in sfs_test1.c and sfs_test2.c).
If longer than that size file names are given it'll fail to create the file but doesn't crash and no catastrophic things happen.


