#include "sfs_state.h"

struct file_descriptor open_files[MAX_OPEN_FILES_COUNT]; // Open file descriptors
struct dir_entry dir_entries[MAX_FILES_COUNT]; // Cached directory entries, all is cached
char inode_bitmap[STD_BLOCK_SIZE];
char block_bitmap[STD_BLOCK_SIZE];
struct inode root_inode;

int file_iter_position;
