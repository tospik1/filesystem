﻿#ifndef SFS_HELPERS_H
#define SFS_HELPERS_H
#include "sfs_state.h"

// SFS Helper functions

// Initialize inode, set all to 0 and set direct/indirect block indexes to -1
void init_inode(struct inode * ind);

// Read inode from disk from specified index
void read_inode(int index, struct inode* inode);

// Write inode to disk at specified index
void write_inode(int index, struct inode* inode);

// Helper function to find empty item in supplied bitmap, either block or inode bitmap would be supplied, but can work on arbitrary one
// this is done to avoid duplicate function code for block/inode cases
int _find_free_item(char* bitmap, int bitmap_block_index, int max_cnt);

// Finds free inode/block respectively
int find_free_inode();
int find_free_block();

// Writes directory entry into disk
int write_dir_entry(int index);

// Returns the opened file index, negative return value means file is not opened
int fd_index(char* filename);

// Returns the index of file in file table, negative return value means file doesn't exist
int file_entry_index(char* filename);

// Opens the file that already exists
int open_file(char* filename, int file_index);

// Creates new file
int create_file(char* filename);

// Writes the data to disk, with additional parameters to be able to write from arbitrary position and size
void write_to_file(int block_num, const char *buf, int pos, int size);

// Reads data from file, similar to write
void read_from_file(int block_num, char *buf, int pos, int size);

// Writes all 0's or 1's (1's as 0xffffff...fffff) respectively
void zero_memory(char* buf, int size);
void one_memory(char* buf, int size);

// Adds block in inode at specified index inside inode (with direct or indirect pointer)
int allocate_block(int inode_index, struct inode* inode, int index);

// Convert from inode relative block index to absolute block index within file system
int absolute_block(struct inode* inode, int index);

// Free the block/inode for later use
void remove_block(int index);
void remove_inode(int index);

// Removes directory entry and updates to disk
void remove_dir_entry(int index);

// Checks if fd is valid, meaning it's in range of max open files and the entry at that index is valid
int is_valid_file_desc(int fd);

#endif // SFS_HELPERS_H
