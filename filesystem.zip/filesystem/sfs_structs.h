#ifndef SFS_STRUCTS_H
#define SFS_STRUCTS_H


struct inode
{
    int mode;
    int link_cnt;
    int uid;
    int gid;
    int size; // File size in bytes, if newly created it's 0
	int direct_ptrs[12];
	int indirect_ptr;
    // Adding unused bytes to make the size convenient, so total size of inode struct will be 128
    char unused[56];
};

struct super_block
{
    int magic_num;
    int block_size;
    int fss_size; // Total amount of blocks
    int inode_table_len; // Amount of blocks for the inode table
    int root_dir_inode;
    // Adding unused bytes to make the total size 1024
    char unused[1004];
};

struct dir_entry
{
    int valid;
    int inode;
    // file length 24 is choosen such that total size of dir entry will be 32 and it'll be convenient to use
    char filename[24];
};

struct file_descriptor {
    int valid;
    int inode;
    char filename[24];
    int position;
    int file_index;
};




#endif
