#ifndef SFS_API_H
#define SFS_API_H

// You can add more into this file.

void mksfs(int);

int sfs_getnextfilename(char*);

int sfs_getfilesize(const char*);

int sfs_fopen(char*);

int sfs_fclose(int);

int sfs_fwrite(int, const char*, int);

int sfs_fread(int, char*, int);

int sfs_fseek(int, int);

int sfs_remove(char*);

// The value is used externally from tests, so defining it here, SFS can't handle bigger than this file name length
// it's the total length including file type extension with '.' and '/' at beginning if using FUSE
#define MAXFILENAME 23


#endif
