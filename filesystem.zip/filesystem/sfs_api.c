#include <stdio.h>

#include "sfs_api.h"
#include "sfs_structs.h"
#include "disk_emu.h"
#include <stdlib.h>
#include <string.h>
#include "sfs_state.h"
#include "sfs_helpers.h"

#define LOG_TEXT(LOG_MSG) fprintf(stdout, LOG_MSG)

void mksfs(int fresh) {
    if (fresh) {
        int err = init_fresh_disk(STD_DISK_NAME, STD_BLOCK_SIZE, BLOCKS_MAX_CNT);
        if (err == -1) {
            LOG_TEXT("disk_emu-init_fresh_disk() failed.");
            return;
        }
        // Initialize super block
        struct super_block sb_instance;
        memset(&sb_instance, 0, sizeof(sb_instance));
        sb_instance.magic_num = SB_MAGIC;
        sb_instance.block_size = STD_BLOCK_SIZE;
        sb_instance.fss_size  = BLOCKS_MAX_CNT;
        sb_instance.inode_table_len = INODE_TABLE_BLOCKS;
        sb_instance.root_dir_inode = 0;
        write_blocks(0, 1, &sb_instance);

        // Initialize root directory inode
        init_inode(&root_inode);
        // Write root inode to disk
        write_inode(0, &root_inode);
        // Initialize open files, all entries are invalid at beginning
        int i;
        for (i = 0; i < MAX_OPEN_FILES_COUNT; ++i) {
            open_files[i].valid = 0;
        }
        // Initialize block and inode bitmaps, all is free except the few reserved at beginning
        // 1 means free block/inode 0 means occupied
        for (i = 0; i < STD_BLOCK_SIZE; ++i){
            inode_bitmap[i] = -1;
            block_bitmap[i] = -1;
        }
        // The -2 is FFFFFFFE such that only 0th bit value is 0 all else 1, 0th is the root inode which is not free
        inode_bitmap[0] = -2;
        // There are total of 32 blocks before data block, each item in bitmap is 8 bits so first 4 items are set as used
        block_bitmap[0] = block_bitmap[1] = block_bitmap[2] = block_bitmap[3] = 0;
        // Write bitmaps to disk
        write_blocks(BLOCK_BITMAP_INDEX, 1, block_bitmap);
        write_blocks(INODE_BITMAP_INDEX, 1, inode_bitmap);
        // No valid directory entry at beginning
        for (i = 0; i < MAX_FILES_COUNT; ++i) {
            dir_entries[i].valid = 0;
        }
        file_iter_position = 0;
    } else {
        int err = init_disk(STD_DISK_NAME, STD_BLOCK_SIZE, BLOCKS_MAX_CNT);
        if (err == -1) {
            LOG_TEXT("disk_emu-init_disk() failed.");
        }
        // Read blocks/inodes bitmap from disk
        read_blocks(BLOCK_BITMAP_INDEX, 1, block_bitmap);
        read_blocks(INODE_BITMAP_INDEX, 1, inode_bitmap);
        // Read root inode from disk
        read_inode(0, &root_inode);

        // Initialize directory entries and open files as invalid, then directory entries will be readed
        // and valid flags set appropriately for files that exist
        int i;
        for (i = 0; i < MAX_OPEN_FILES_COUNT; ++i) {
            open_files[i].valid = 0;
        }
        for (i = 0; i < MAX_FILES_COUNT; ++i) {
            dir_entries[i].valid = 0;
        }
        // Load all directory entries from disk, root inode blocks are readed one by one then directory entries are initialized
        for (i = 0; i < root_inode.size; i+=STD_BLOCK_SIZE) {
            char read_buf[STD_BLOCK_SIZE];
            int block_index = i / STD_BLOCK_SIZE;
            read_blocks(absolute_block(&root_inode, block_index), 1, read_buf);
            int j;
            for (j = 0; j < DIR_ENTRY_PER_BLOCK && block_index * DIR_ENTRY_PER_BLOCK + j < MAX_FILES_COUNT; ++j) {
                memcpy(&(dir_entries[block_index * DIR_ENTRY_PER_BLOCK + j]), read_buf + j*sizeof(dir_entries[0]), sizeof(dir_entries[0]));
            }
        }
        file_iter_position = 0;
    }
}

int sfs_getnextfilename(char* filename) {
    // Go forward until either valid entry found or reached max count
    while (file_iter_position < MAX_FILES_COUNT && !dir_entries[file_iter_position].valid) {
        file_iter_position++;
    }
    // If valid entry was found, not that it reached to end
    if (file_iter_position < MAX_FILES_COUNT && dir_entries[file_iter_position].valid) {
        strcpy(filename, dir_entries[file_iter_position].filename);
        file_iter_position++; // Next time when called will start from next file
        return 1;
    }
    // Reached the end, now resetting to begin (such that will be able to list files as many times wished)
    file_iter_position = 0;
    return 0;
}

int sfs_getfilesize(const char* filename) {
    int i;
    // Find the file from dir entries
    for (i = 0; i < MAX_FILES_COUNT; ++i) {
        if (dir_entries[i].valid && strcmp(dir_entries[i].filename, filename) == 0) {
            // Read the corresponding inode from disk and get the size
            struct inode inode;
            read_inode(dir_entries[i].inode, &inode);
            return inode.size;
        }
    }
    return -1;
}

// Look if the file is already opened, if opened do nothing
// if not opened, search in directory
// if no such file exists, create it on 1st possible free space in directory
// then find empty space in file descriptors and create descriptor
int sfs_fopen(char* filename) {
    // Checking file length here to avoid later checking multiple times
    if (strlen(filename) > MAX_FILE_LENGTH) {
        return -1;
    }

    // If file exists and already opened
    {
        int open_index = fd_index(filename);
        if (open_index >= 0) {
            return open_index;
        }
    }

    // File is not opened, check if it exists
    int file_index = file_entry_index(filename);
    if (file_index >= 0) { // File exists, now will open it
        return open_file(filename, file_index);
    } else {
        // File doesn't exist, creating it
        file_index = create_file(filename);
        if (file_index < 0) { // Check if creating failed return fail
            return file_index;
        }
        return open_file(filename, file_index);
    }
}

// As done in writing, start from the seeked position
// read block by block and accumulate, until count is finished
int sfs_fread(int file_desc, char* buf, int size) {
    // If file is not opened, don't proceed
    if (!is_valid_file_desc(file_desc)) {
        return 0;
    }

    // Read the inode for file
    struct inode inode;
    read_inode(open_files[file_desc].inode, &inode);

    // Calculate the size that will be readen, if file doesn't have enough data starting at last seek position, then less than size is read
    {
        int max_size = inode.size - open_files[file_desc].position;
        if (max_size < size) {
            size = max_size;
        }
    }

    // This is the index to read last byte + 1, such that file position will become end_pos when finished
    int end_pos = open_files[file_desc].position + size;

    // Continously reading blocks and incrementing position until reaching end position
    // when position == end_pos no more reading
    while (open_files[file_desc].position < end_pos) {
        // If position is not at start of block, calculate the remaining bytes before next block
        int read_size = STD_BLOCK_SIZE - (open_files[file_desc].position % STD_BLOCK_SIZE);
        // Cut read size if it's last block to read and not till the end of block
        if (end_pos - open_files[file_desc].position < read_size) {
            read_size = end_pos - open_files[file_desc].position;
        }
        // In file system block index is calculated and part of it is readed, starting from the specified position and count
        read_from_file(absolute_block(&inode, open_files[file_desc].position / STD_BLOCK_SIZE), buf, open_files[file_desc].position % STD_BLOCK_SIZE, read_size);
        // Buffer and file position for next read is advanced
        buf += read_size;
        open_files[file_desc].position += read_size;
    }

    return size;
}

// Do initial checks, then start from current position and write block by block
// until either no more data to write or can't allocate space
int sfs_fwrite(int file_desc, const char* buf, int size) {
    // If file is not opened, don't proceed
    if (!is_valid_file_desc(file_desc)) {
        return 0;
    }

    // Read the inode for file
    struct inode inode;
    read_inode(open_files[file_desc].inode, &inode);

    // end_pos is the expected position if there is enough space to write all the data
    // if no enough space found then end_pos is adjusted accrodingly
    int end_pos = open_files[file_desc].position + size;
    // Saving current position to later measure how much was written
    int begin_pos = open_files[file_desc].position;
    // Write blocks until no more data to write or no space available
    while (open_files[file_desc].position < end_pos) {
        // If position is not at start of block, calculate the remaining bytes before next block
        int write_size = STD_BLOCK_SIZE - (open_files[file_desc].position % STD_BLOCK_SIZE);
        // Cut write size if it's last block to write and not till the end of block
        if (end_pos - open_files[file_desc].position < write_size) {
            write_size = end_pos - open_files[file_desc].position;
        }
        // Try to allocate block, if no more space available then it gracefully stops writing
        if (allocate_block(open_files[file_desc].inode, &inode, open_files[file_desc].position / STD_BLOCK_SIZE) < 0) {
            break;
        }

        // In file system block index is calculated and part of it is written, starting from the specified position and count
        write_to_file(absolute_block(&inode, open_files[file_desc].position / STD_BLOCK_SIZE), buf, open_files[file_desc].position % STD_BLOCK_SIZE, write_size);
        // Buffer and file position for next write is advanced
        buf += write_size;
        open_files[file_desc].position += write_size;
    }

    // If the file size is increased update it in inode to reflect it
    if (open_files[file_desc].position > inode.size) {
        inode.size = open_files[file_desc].position;
    }

    // Write the file inode into disk
    write_inode(open_files[file_desc].inode, &inode);
    // begin_pos is the original position, so actual written bytes count is the difference between current and original position
    return open_files[file_desc].position - begin_pos;
}

int sfs_fseek(int file_desc, int pos) {
    if (!is_valid_file_desc(file_desc)) {
        return -1;
    }

    // Reading the inode to get the file size
    struct inode inode;
    read_inode(open_files[file_desc].inode, &inode);
    // If position equals to size it will point at end of file for appending
    if (pos < 0 || pos > inode.size) {
        return -1;
    }
    // Simply putting position
    open_files[file_desc].position = pos;
    return 0;
}

int sfs_fclose(int file_desc) {
    // Check if file is not opened or already closed, return indicating error
    if (!is_valid_file_desc(file_desc)) {
        return -1;
    }
    // Otherwise close and return success
    open_files[file_desc].valid = 0;
    return 0;
}

int sfs_remove(char* filename) {
    int index = file_entry_index(filename);
    // If no such file exists return error
    if (index < 0) {
        return -1;
    }
    int fd = fd_index(filename);
    if (fd >= 0) {
        sfs_fclose(fd);
    }
    struct inode inode;
    read_inode(dir_entries[index].inode, &inode);

    // Free all the blocks occupied by file
    for (int i = 0; i < (inode.size+STD_BLOCK_SIZE-1) / STD_BLOCK_SIZE; ++i) {
        remove_block(absolute_block(&inode, i));
    }
    // In case of having valid indirect pointer free the block to which it points
    if (inode.indirect_ptr >= 0) {
        remove_block(inode.indirect_ptr);
    }
    remove_inode(dir_entries[index].inode); // Free the inode
    remove_dir_entry(index); // Remove dir entry from file table and update to disk
    return 1; // Anything non negative means success
}



