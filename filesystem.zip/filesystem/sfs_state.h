#ifndef SFS_STATE_H
#define SFS_STATE_H
#include "sfs_structs.h"

#define STD_DISK_NAME "sample_disk_name.fs"
#define STD_BLOCK_SIZE 1024
//#define SUPERBLOCK_INDEX 0 // Sure superblock is at beginning
// Block indexes for block and inode bitmaps, inode bitmap is used same way as block bitmap
#define BLOCK_BITMAP_INDEX 1
#define INODE_BITMAP_INDEX 2

#define INODE_TABLE_INDEX 3 // Start of inode table
// Inode table blocks choosen 29 so data blocks start at 32 (0x20)
#define INODE_TABLE_BLOCKS 29
#define FIRST_DATA_BLOCK 32
// The 8 comes from 1024 / 128, block size / inode struct size
#define INODE_PER_BLOCK 8
// Maximum is INODE_TABLE_BLOCKS * INODE_PER_BLOCK which is 232
#define INODE_MAX_CNT 232

// Can put this maximum 1024*8 (1 block bitmap 1024 bytes has 8192 bits)
#define BLOCKS_MAX_CNT 2048

#define SB_MAGIC 0xACBD0005

// Max. files lesser than inodes count, at least 1 less for root inode
#define MAX_FILES_COUNT 150
#define MAX_OPEN_FILES_COUNT 100
// Directory entry struct is 32 bytes, so there are 32 entries per block
#define DIR_ENTRY_PER_BLOCK 32

// The MAXFILENAME was used externally to use SFS, and MAX_FILE_LENGTH is the SFS internal, so putting equal to each other, currently it's set to 23
#define MAX_FILE_LENGTH MAXFILENAME


extern struct file_descriptor open_files[MAX_OPEN_FILES_COUNT]; // Open file descriptors
extern struct dir_entry dir_entries[MAX_FILES_COUNT]; // Cached directory entries, all is cached
extern char inode_bitmap[STD_BLOCK_SIZE];
extern char block_bitmap[STD_BLOCK_SIZE];
extern struct inode root_inode;

extern int file_iter_position; // used for iterating through files


#endif // SFS_STATE_H
