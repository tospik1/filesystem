#include "sfs_helpers.h"
#include "disk_emu.h"
#include "string.h"
#include "stdio.h"

void init_inode(struct inode * ind) {
    memset(ind, 0, sizeof(*ind));
    int iter = 0;
    for (; iter < 12; ++iter) {
        ind->direct_ptrs[iter] = -1;
    }
    ind->indirect_ptr = -1;
}

void read_inode(int index, struct inode* inode) {
    // Block index in which it's located, and the index within that block
    int block_index = index / INODE_PER_BLOCK;
    int item_index = index % INODE_PER_BLOCK;
    char block_buf[STD_BLOCK_SIZE];
    // Read the required block, then copy the inode data to supplied argument
    read_blocks(INODE_TABLE_INDEX + block_index, 1, block_buf);
    memcpy(inode, block_buf + item_index*sizeof(*inode), sizeof(*inode));
}

void write_inode(int index, struct inode* inode) {
    // Block index in which it's located, and the index within that block
    int block_index = index / INODE_PER_BLOCK;
    int item_index = index % INODE_PER_BLOCK;
    char block_buf[STD_BLOCK_SIZE];

    // Read the required block from disk, update it and then write to disk
    read_blocks(INODE_TABLE_INDEX + block_index, 1, block_buf);
    memcpy(block_buf + item_index*sizeof(*inode), inode, sizeof(*inode));
    write_blocks(INODE_TABLE_INDEX + block_index, 1, block_buf);
}


int _find_free_item(char* bitmap, int bitmap_block_index, int max_cnt) {
    int i;
    // Checking for empty item in bitmap, here count is divided by 8 is bits count of char type
    for (i = 0; i < max_cnt/8; ++i) {
        // There's a bit in that byte that is not 0, proceed to occupy it
        if (bitmap[i]) {
            int k;
            char byte = bitmap[i];
            for (k = 0; k < 8; ++k) {
                if ( (byte >> k) & 1) { // Checking if k-th bit is 1 (meaning free)
                    int free_index = i*8+k;
                    byte = byte - (1 << k); // Sets the k-th bit into 0
                    bitmap[i] = byte; // Update the byte in bitmap
                    write_blocks(bitmap_block_index, 1, bitmap); // Update to disk
                    return free_index;
                }
            }
        }
    }
    return -1;
}

int find_free_inode() {
    return _find_free_item(inode_bitmap, INODE_BITMAP_INDEX, INODE_MAX_CNT);
}

int find_free_block() {
    return _find_free_item(block_bitmap, BLOCK_BITMAP_INDEX, BLOCKS_MAX_CNT);
}

int write_dir_entry(int index) {
    int block_index = index / DIR_ENTRY_PER_BLOCK;
    int item_index = index % DIR_ENTRY_PER_BLOCK;
    char block_buf[STD_BLOCK_SIZE];

    int abs_block = absolute_block(&root_inode, block_index);
    // Check if need to add block to root inode to add the entry
    if (abs_block < 0) {
        if (allocate_block(0, &root_inode, block_index) < 0) {
            return -1;
        }
        // Note that allocate_block doesn't fill the block, but for dir entries must make sure the valid flag is false for not-yet occupied entries
        zero_memory(block_buf, STD_BLOCK_SIZE);
    } else {
        // No new block allocated, so reading it from disk
        read_blocks(abs_block, 1, block_buf);
    }
    // Write the entry to buffer and then write to disk
    memcpy(block_buf + item_index*sizeof(dir_entries[index]), &dir_entries[index], sizeof(dir_entries[index]));
    write_blocks(absolute_block(&root_inode, block_index), 1, block_buf);

    return 1;
}

int fd_index(char* filename) {
    int i;
    for (i = 0; i < MAX_OPEN_FILES_COUNT; ++i) {
        if (open_files[i].valid && strcmp(open_files[i].filename, filename) == 0) {
            return i;
        }
    }
    return -1;
}

int file_entry_index(char* filename) {
    int i;
    for (i = 0; i < MAX_FILES_COUNT; ++i) {
        // Check if such file already exists
        if (strcmp(dir_entries[i].filename, filename) == 0) {
            return i;
        }
    }
    return -1;
}

int open_file(char* filename, int file_index) {
    int i;
    for (i = 0; i < MAX_OPEN_FILES_COUNT; ++i) {
        if (!open_files[i].valid) { // Empty entry is found on fd table
            open_files[i].valid = 1;
            open_files[i].inode = dir_entries[file_index].inode;
            strcpy(open_files[i].filename, filename);

            struct inode file_inode;
            read_inode(dir_entries[file_index].inode, &file_inode);
            open_files[i].position = file_inode.size; // Opening in append mode, position at end
            open_files[i].file_index = file_index;
            return i;
        }
    }
    return -1;
}

int create_file(char* filename) {
    int i;
    for (i = 0; i < MAX_FILES_COUNT; ++i) {
        if (!dir_entries[i].valid) {
            int inode_num = find_free_inode();
            if (inode_num < 0) {
                return -1;
            }
            strcpy(dir_entries[i].filename, filename);
            dir_entries[i].inode = inode_num;
            dir_entries[i].valid = 1;
            // Trying to write to disk, it can fail if can't allocate block for root inode, in that case reverting it
            if (write_dir_entry(i) < 0) {
                dir_entries[i].valid = 0;
                return -1;
            }
            // Root inode size gets expanded if used higher index that was not yet been written
            if ( (i+1) * sizeof(struct dir_entry) > root_inode.size) {
                root_inode.size = (i+1) * sizeof(struct dir_entry) > root_inode.size;
            }
            struct inode inode;
            init_inode(&inode);
            write_inode(inode_num, &inode);
            write_inode(0, &root_inode);
            return i;
        }
    }
    return -1;
}


void write_to_file(int block_num, const char *buf, int pos, int size) {
    // Reads the block from disk, writes the required part as specified by pos and size, then writes back to disk
    char read_buf[STD_BLOCK_SIZE];
    read_blocks(block_num, 1, read_buf);
    memcpy(read_buf+pos, buf, size);
    write_blocks(block_num, 1, read_buf);
}
void read_from_file(int block_num, char *buf, int pos, int size) {
    // Reads the block from disk, then copies content from pos into supplied buffer
    char read_buf[STD_BLOCK_SIZE];
    read_blocks(block_num, 1, read_buf);
    memcpy(buf, read_buf+pos, size);
}

void zero_memory(char* buf, int size) {
    memset(buf, 0, size);
}
void one_memory(char* buf, int size) {
    memset(buf, -1, size);
}

int allocate_block(int inode_index, struct inode* inode, int index) {
    // This is the maximum file size limit in blocks, it's 268, if index >= 268 then return error
    if (index >= 12 + STD_BLOCK_SIZE / sizeof(int)) {
        return -1;
    }
    // Allocate direct pointer
    if (index < 12) {
        if (inode->direct_ptrs[index] < 0) {
            inode->direct_ptrs[index] = find_free_block();
            if (inode->direct_ptrs[index] < 0) {
                return -1;
            }
        }
    } else { // Allocate in indirect pointer
        if (inode->indirect_ptr < 0) { // Indirect pointer not valid yet, allocating it now
            int indirect_block = find_free_block();
            if (indirect_block < 0) {
                return -1;
            }
            // Indirect pointer block should contain all -1 at beginning, so writing all 1's accomplishes it (since -1 is all 1's in binary)
            char indir_buf[STD_BLOCK_SIZE];
            one_memory(indir_buf, STD_BLOCK_SIZE);
            inode->indirect_ptr = indirect_block;
            int free_block = find_free_block();
            // Indirect block is ok but can't allocate data block
            if (free_block < 0) {
                // In this case the inode was modified but not fully finished the task
                // so updating changes to disk and returning error
                write_blocks(inode->indirect_ptr, 1, indir_buf);
                write_inode(inode_index, inode);
                return -1;
            }
            *((int*) indir_buf + (index-12)) = free_block;
            write_blocks(inode->indirect_ptr, 1, indir_buf);
        } else { // There's valid indirect pointer in inode
            char indir_buf[STD_BLOCK_SIZE];
            read_blocks(inode->indirect_ptr, 1, indir_buf);
            if (*((int*) indir_buf + (index-12)) < 0) {
                int free_block = find_free_block();
                if (free_block < 0) {
                    return -1;
                }
                *((int*) indir_buf + (index-12)) = free_block;
                write_blocks(inode->indirect_ptr, 1, indir_buf);
            }
        }
    }
    write_inode(inode_index, inode);
    return 1;
}

int absolute_block(struct inode* inode, int index) {
    if (index < 12) { // If within range of direct pointers
        return inode->direct_ptrs[index];
    } else { // It's in indirect pointer range
        // Indirect pointer is invalid, so returning error
        if (inode->indirect_ptr < 0) {
            return -1;
        }
        // Read indirect block
        char indir_buf[STD_BLOCK_SIZE];
        read_blocks(inode->indirect_ptr, 1, indir_buf);
        if (*((int*)indir_buf + (index-12)) > BLOCKS_MAX_CNT) {
            printf("SFS Error: absolute block is beyond max blocks %d\n", *((int*)indir_buf + (index-12)));
            return -1;
        }
        // Indirect block contains 4 byte indexes for blocks, so first converting into int type,
        // then offseting by index-12 since there are 12 direct blocks, then dereferencing it
        return *((int*)indir_buf + (index-12));
    }
}

void remove_block(int index) {
    // Mark the block as free
    block_bitmap[index/8] += 1 << (index%8);
    write_blocks(BLOCK_BITMAP_INDEX, 1, block_bitmap);
}

void remove_inode(int index) {
    // Mark the inode as free
    inode_bitmap[index/8] += 1 << (index%8);
    write_blocks(INODE_BITMAP_INDEX, 1, inode_bitmap);
}

void remove_dir_entry(int index) {
    // Calculating block index for that entry (block number inside root inode, not physical block number)
    int block_index = index / DIR_ENTRY_PER_BLOCK;
    // Calculating index of entry within the block, since each block contains multiple inodes
    int item_index = index % DIR_ENTRY_PER_BLOCK;
    char block_buf[STD_BLOCK_SIZE];
    dir_entries[index].valid = 0;

    // Read the block the directory entry is in, update it and write to disk
    read_blocks(absolute_block(&root_inode, block_index), 1, block_buf);
    memcpy(block_buf + item_index*sizeof(dir_entries[index]), &(dir_entries[index]), sizeof(dir_entries[index]));
    write_blocks(absolute_block(&root_inode, block_index), 1, block_buf);
}

int is_valid_file_desc(int desc) {
    return desc >= 0 && desc < MAX_OPEN_FILES_COUNT && open_files[desc].valid;
}

